# ConductorChargeDistribution

A simulation of movement of charges within a conductor.  Users may adjust the charge and shape of the conductor as well as expose it to external charges to observe the reaction.  Created using Easy Java Simulations (http://fem.um.es/Ejs/).  