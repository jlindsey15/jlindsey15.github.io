# FlashcardRevolution

Authors: Jack Lindsey and Vince Cozza

A simple GUI application that allows users to create digital "flashcards" and use them to study.  Flashcards can be tagged and saved to / loaded from files. 
