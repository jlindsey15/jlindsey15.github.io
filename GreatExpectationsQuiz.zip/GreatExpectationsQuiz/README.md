# GreatExpectationsQuiz


Author: Jack Lindsey

My first ever programming project (from back in 9th grade)!  A program that presents the user with a series of scenarios and then purports to tell him/her which character from Great Expectations he/she most closely resembles.
