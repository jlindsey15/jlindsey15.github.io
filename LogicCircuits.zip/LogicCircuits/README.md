# LogicCircuits

Authors: Jack Lindsey and Maria Messick

A GUI application that enables logic circuit simulation.  By default, supports 'and,' 'or,' and 'not' gates.  Allows user-defined gates to be saved and loaded as "black boxes."  Entire circuits can also be saved.
